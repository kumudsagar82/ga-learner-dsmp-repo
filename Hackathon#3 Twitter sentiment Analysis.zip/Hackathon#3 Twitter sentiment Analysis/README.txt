Files:

# Initail file
Hackathon3_initial_Aniket.ipynb

# trying oversampling
Oversampling_prediction_hack3.ipynb

# Cleaning & EDA
Hack3_Cleaning_refined.ipynb
Hack3_EDA_cleaning.ipynb
hack3_Textblob.ipynb
hackathonsentimentanalysisedabyfinalfuncc .ipynb #name entity recog

# Word2vec
hacksentimentanalysiswithword2vecwithallmodels.ipynb

#Text blob
additoional/HACKATHONMODELWITHTEXTBLOB.ipynb
additoional/hackathonedaonpositivenegativesentimentsv2.ipynb

#tried
Hack_cleaning_using_gingerit.ipynb

# Final modelling file
Hack3_rf_r3_predictionv2_FINAL.ipynb

# Final submission file
submission_r0_lr_cv_stem_best_params_v2_FINAL.csv